This repository contains the course assigment of ELEN6889: large data stream processing.
